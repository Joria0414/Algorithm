package ʵ��;

import java.util.LinkedList;

class Random{
	public static double portTime() {
		return (4+40*Math.random());
	}
	public static double arrivalInterval() {
		return (15+30*Math.random());
	}
}

class Ship{
	public double arrival,in,out;
	int seq;
	public Ship(double arrival,double in,int seq) {
		this.arrival=arrival;
		this.in=in;
		out=in+Random.portTime();
		this.seq=seq;
	}
}

public class MainClass {
	private int seq;
	private double nextArrival;
	private double nextIn;
	private double maxTime;
	private LinkedList<Ship> queue;
	private LinkedList<Ship> ships;
	public MainClass(double maxTime) {
		nextArrival=0;
		nextIn=0;
		seq=1;
		this.maxTime=maxTime;
		queue=new LinkedList<Ship>();
		ships=new LinkedList<Ship>();
		
	}
	public void run() {
		while(true) {
			if(this.nextArrival>this.maxTime) {
				while(!queue.isEmpty()) {
					Ship ship=queue.removeFirst();
					this.ships.addLast(ship);
					//save queue
				}
				return;
			}
			if(this.nextIn>this.nextArrival) {
				if(queue.isEmpty()) {
					double in;
					if(this.nextArrival>this.nextIn) in=this.nextArrival;
					else in=this.nextIn;
					addShip(this.nextArrival, in);
				}
				else {
					Ship tmp=queue.getLast();
					double in=tmp.out;
					addShip(this.nextArrival, in);
				}
			}
			else if(this.nextIn<this.nextArrival&&(!queue.isEmpty())) {
				popShip();
			}
			else {
				if(!queue.isEmpty()) {
					popShip();
				}
				if(queue.isEmpty()) {
					double in;
					if(this.nextArrival>this.nextIn) in=this.nextArrival;
					else in=this.nextIn;
					addShip(this.nextArrival, in);
				}
				else {
					Ship tmp=queue.getLast();
					double in=tmp.out;
					addShip(this.nextArrival, in);
				}
			}
		}
	}
	public void addShip(double arrival,double in) {
		Ship ship=new Ship(arrival, in, this.seq);
		//System.out.println("seq:"+this.seq);
		this.seq++;
		this.nextArrival+=Random.arrivalInterval();
		//System.out.println("next arrival:"+this.nextArrival);
		this.queue.addLast(ship);
		//save queue
	}
	public void popShip() {
		Ship ship=queue.removeFirst();
		this.nextIn=ship.out;
		this.ships.addLast(ship);
		//save queue
	}
	public void show(int x) {
		double cost=0;
		int num=0;
		int total=0;
		for(int j=0;j<x;j++) {
			run();
			total+=ships.size();
			for(int i=0;i<ships.size();i++) {
				Ship tmp=ships.get(i);
				if(tmp.in>tmp.arrival) {
					num++;
					cost+=1000*(tmp.in-tmp.arrival);
				}
			}
		}
		num=num/x;
		cost/=x;
		total/=x;
		System.out.println("total wait ships:"+num);
		System.out.println("total cost:"+cost);
		System.out.println("total ships:"+total);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainClass mainClass=new MainClass(24*30*12*5);
		mainClass.show(100);
	}

}
